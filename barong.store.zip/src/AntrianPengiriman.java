public class AntrianPengiriman {
    NodePesanan front;
    NodePesanan tail;
    int size;

    private class NodePesanan {
        Pesanan pesanan;
        NodePesanan next;

        NodePesanan(Pesanan pesanan) {
            this.pesanan = pesanan;
            this.next = null;
        }
    }

    public AntrianPengiriman() {
        this.front = null;
        this.tail = null;
        this.size = 0;
    }

    public void tambahAntrian(Pesanan pesanan) {
        NodePesanan nodeBaru = new NodePesanan(pesanan);
        if (tail == null) {
            front = tail = nodeBaru;
        } else {
            tail.next = nodeBaru;
            tail = nodeBaru;
        }
        size++;
    }

    public Pesanan keluarAntrian() {
        if (front == null) return null;
        
        Pesanan pesanan = front.pesanan;
        front = front.next;
        
        if (front == null) {
            tail = null;
        }
        
        size--;
        return pesanan;
    }
}
