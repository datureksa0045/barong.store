public class Pesanan {
    String IdPesanan;
    Produk produkPertama;
    String namaPelanggan;
    String status;
    int jumlahProduk;

    public Pesanan(String IdPesanan, String namaPelanggan) {
        this.IdPesanan = IdPesanan;
        this.namaPelanggan = namaPelanggan;
        this.produkPertama = null;
        this.status = "Diproses";
        this.jumlahProduk = 0;
    }
    public void tambahProduk(NodeProduk produk) {
        Produk newProduk = new Produk(produk);
        if (produkPertama == null) {
            produkPertama = newProduk;
        } else {
            Produk current = produkPertama;
            while (current.next != null) {
                current = current.next;
            }
            current.next= newProduk;
        }
        jumlahProduk++;
    }
}